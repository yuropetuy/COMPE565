HW3 by Brent Son and Kaia Ralston

Steps to run MATLAB Script:

1. Make sure that the 'walk_qcif.avi' file is in the same directory as 'hw_3_script.m'. 

2. Open 'hw_3_script.m' and add it to PATH. 

3. Hit run and the script should open all needed figures, that are also shown in the submission document.